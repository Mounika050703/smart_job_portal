<?php

function jp_job_list_shortcode() {
    global $wpdb;
    $table = $wpdb->prefix . 'jp_jobs';

    $jobs = $wpdb->get_results("SELECT * FROM $table");

    ob_start();

    foreach ($jobs as $job) {
        echo "<h3>$job->title</h3>";
        echo "<p>$job->description</p>";
        echo "<a href='?apply=" . $job->id . "'>Apply</a>";
    }

    return ob_get_clean();
}

add_shortcode('job_list', 'jp_job_list_shortcode');
