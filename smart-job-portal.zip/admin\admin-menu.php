<?php

add_action('admin_menu', function() {
    add_menu_page('Job Portal', 'Job Portal', 'manage_options', 'jp-dashboard', 'jp_dashboard');

    add_submenu_page('jp-dashboard', 'Jobs', 'Jobs', 'manage_options', 'jp-jobs', 'jp_jobs_page');
    add_submenu_page('jp-dashboard', 'Applicants', 'Applicants', 'manage_options', 'jp-applicants', 'jp_applicants_page');
});

function jp_dashboard() {
    echo "<h1>Job Portal Dashboard</h1>";
}
