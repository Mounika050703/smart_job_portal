<?php

function jp_apply_job() {
    if (!is_user_logged_in()) {
        return "Please login to apply.";
    }

    if (isset($_POST['apply'])) {
        global $wpdb;

        $file = $_FILES['resume'];
        $upload = wp_upload_bits($file['name'], null, file_get_contents($file['tmp_name']));

        $wpdb->insert($wpdb->prefix . 'jp_applications', [
            'job_id' => $_POST['job_id'],
            'user_id' => get_current_user_id(),
            'resume' => $upload['url']
        ]);

        echo "Applied Successfully!";
    }

    ?>
    <form method="post" enctype="multipart/form-data">
        <input type="hidden" name="job_id" value="<?php echo $_GET['apply']; ?>">
        <input type="file" name="resume" required>
        <button name="apply">Apply</button>
    </form>
    <?php
}

add_shortcode('apply_job', 'jp_apply_job');
