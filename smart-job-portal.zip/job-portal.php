<?php
/*
Plugin Name: Smart Job Portal
Description: Custom Job Portal Plugin
Version: 1.0
*/

if (!defined('ABSPATH')) exit;

// Activation Hook
register_activation_hook(__FILE__, 'jp_create_tables');

function jp_create_tables() {
    global $wpdb;

    $jobs = $wpdb->prefix . 'jp_jobs';
    $apps = $wpdb->prefix . 'jp_applications';

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    $sql1 = "CREATE TABLE $jobs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255),
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";

    $sql2 = "CREATE TABLE $apps (
        id INT AUTO_INCREMENT PRIMARY KEY,
        job_id INT,
        user_id INT,
        resume VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";

    dbDelta($sql1);
    dbDelta($sql2);
}

// Include files
require_once plugin_dir_path(__FILE__) . 'includes/functions.php';
require_once plugin_dir_path(__FILE__) . 'admin/admin-menu.php';
