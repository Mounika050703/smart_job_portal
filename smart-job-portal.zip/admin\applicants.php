<?php

function jp_applicants_page() {
    global $wpdb;
    $table = $wpdb->prefix . 'jp_applications';

    $results = $wpdb->get_results("SELECT * FROM $table");

    echo "<h2>Applicants</h2>";

    foreach ($results as $row) {
        echo "<p>User ID: $row->user_id | Resume: $row->resume</p>";
    }
}
