<?php

function jp_jobs_page() {
    global $wpdb;
    $table = $wpdb->prefix . 'jp_jobs';

    if (isset($_POST['submit'])) {
        $wpdb->insert($table, [
            'title' => $_POST['title'],
            'description' => $_POST['description']
        ]);
        echo "Job Added!";
    }

    ?>
    <h2>Add Job</h2>
    <form method="post">
        <input type="text" name="title" placeholder="Job Title" required><br>
        <textarea name="description" placeholder="Description"></textarea><br>
        <button type="submit" name="submit">Add Job</button>
    </form>
    <?php
}
