<?php
// Core functions for Job Portal plugin
// This file can be extended with additional utility functions
